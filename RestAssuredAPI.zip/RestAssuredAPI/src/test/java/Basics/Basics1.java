package Basics;

import io.restassured.RestAssured;
import static io.restassured.RestAssured.*;

public class Basics1 {
	
	
	public static String createPlaceData()
	{
		String b="{\r\n"
				+ "  \"Envelope\": {\r\n"
				+ "    \"Header\": \"\",\r\n"
				+ "    \"Body\": {\r\n"
				+ "      \"CapitalCity\": {\r\n"
				+ "        \"sCountryISOCode\": \"IN\"\r\n"
				+ "      }\r\n"
				+ "    }\r\n"
				+ "  }\r\n"
				+ "}";
	return b;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		RestAssured.baseURI= "http://webservices.oorsprong.org";
		String response=given().log().all().header("Content-Type","application/json").body(Basics1.createPlaceData())
		.when().post("websamples.countryinfo/CountryInfoService.wso").asPrettyString();
		System.out.println(response);
		
	}

}



/*
 * { "Envelope": { "Header": "", "Body": { "CapitalCity": { "sCountryISOCode":
 * "IN" } } } }
 */