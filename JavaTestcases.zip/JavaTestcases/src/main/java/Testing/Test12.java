package Testing;

import org.json.JSONObject;

public class Test12 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
        String jsonString = "{\r\n"
        		+ "    \"Header\": {\r\n"
        		+ "        \"clientId\": \"ALFARIS\",\r\n"
        		+ "        \"schemeId\": \"TESTLOAN\",\r\n"
        		+ "        \"MsgReference\": \"axushgsdf78899d99s\"\r\n"
        		+ "    },\r\n"
        		+ "    \"Data\": {\r\n"
        		+ "        \"RemitterDetails\": [\r\n"
        		+ "            {\r\n"
        		+ "                \"email\": \"reshnuchandrn8452@gmail.com\",\r\n"
        		+ "                \"invoiceNotify\": \"E\",\r\n"
        		+ "                \"mobile\": \"0548735986\",\r\n"
        		+ "                \"notifLang\": \"0\",\r\n"
        		+ "                \"remitterId\": \"10101245730\",\r\n"
        		+ "                \"remitterName\": \"ReshnuMC\",\r\n"
        		+ "                \"operationCode\": \"U\",\r\n"
        		+ "                \"maximumAmnt\": null\r\n"
        		+ "            }\r\n"
        		+ "        ]\r\n"
        		+ "    },\r\n"
        		+ "    \"Signature\": \"\"\r\n"
        		+ "}";
        
        try {
            com.fasterxml.jackson.databind.ObjectMapper mapper = new com.fasterxml.jackson.databind.ObjectMapper();
            java.util.LinkedHashMap obj = (java.util.LinkedHashMap) mapper.readValue(jsonString, Object.class);
            java.util.LinkedHashMap result = (java.util.LinkedHashMap) obj.get("Header");
            result.put("MsgReference", "Testing");
            System.out.println(obj);
            java.io.ByteArrayOutputStream bout = new java.io.ByteArrayOutputStream();
            mapper.writeValue(bout, obj);
            byte[] objectBytes = bout.toByteArray();
            jsonString = new String(objectBytes);
        } catch (java.io.IOException e) {
            e.printStackTrace();
        }
		/*
		 * JSONObject jObject = new JSONObject(jsonArray);
		 * jObject.getJSONObject("Header").put("MsgReference", "N/A");
		 * System.out.println(jObject);
		 */

	}

}
