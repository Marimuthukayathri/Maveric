package Testing;


	import org.json.JSONException;
	import org.json.JSONObject;
import org.json.simple.JSONValue;
import org.json.simple.parser.JSONParser;

	public class Test11 {

	    public static void main(String[] args) throws Throwable {
	        String jsonArray = "{\r\n"
	        		+ "    \"DebugHeader\": {\r\n"
	        		+ "        \"clientId\": \"ALFARIS\",\r\n"
	        		+ "        \"schemeId\": \"TESTLOAN\",\r\n"
	        		+ "        \"MsgReference\": \"axushgsdf78899d99s\"\r\n"
	        		+ "    },\r\n"
	        		+ "    \"Data\": {\r\n"
	        		+ "        \"RemitterDetails\": [\r\n"
	        		+ "            {\r\n"
	        		+ "                \"email\": \"reshnuchandrn8452@gmail.com\",\r\n"
	        		+ "                \"invoiceNotify\": \"E\",\r\n"
	        		+ "                \"mobile\": \"0548735986\",\r\n"
	        		+ "                \"notifLang\": \"0\",\r\n"
	        		+ "                \"remitterId\": \"10101245730\",\r\n"
	        		+ "                \"remitterName\": \"ReshnuMC\",\r\n"
	        		+ "                \"operationCode\": \"U\",\r\n"
	        		+ "                \"maximumAmnt\": null\r\n"
	        		+ "            }\r\n"
	        		+ "        ]\r\n"
	        		+ "    },\r\n"
	        		+ "    \"Signature\": \"\"\r\n"
	        		+ "}";
	        
	        
	        JSONObject jsonObject = new JSONObject(jsonArray);  
	      String[] name =  jsonObject.getNames(jsonObject);  
	      
	      for (String sttt: name) {
	      		
	      		System.out.println("String names are "+sttt);
	      		if (sttt.contains("Header")) {
	      			jsonObject.getJSONObject(sttt).put("MsgReference", "N/A");
	      		 System.out.println(jsonObject);
	      			
	      		}
	      		
	      	}
	      	
			/*
			 * System.out.println(name); JSONObject json = new JSONObject(jsonArray);
			 * System.out.println(json.toString()); System.out.println();
			 * 
			 * String technology = json.getString("Data");
			 * System.out.println("Tech is "+technology);
			 * 
			 */
			/*
			 * JSONParser parser = new JSONParser(); JSONObject json = (JSONObject)
			 * parser.parse(jsonArray); System.out.println(json);
			 */       
	//        JSONObject jObject = new JSONObject(jsonArray);
	//        jObject.getString(jsonArray).replaceAll("MsgReference", ""); 
//	        jObject.getJSONObject("Header").put("MsgReference", "N/A");
	     //   System.out.println(jObject);
	    }

	}