package Testing;

import java.util.UUID;

import net.bytebuddy.utility.RandomString;

class MyUuidApp {
    public static void main(String[] args) {
        UUID uuid = UUID.randomUUID();
        String uuidAsString = uuid.toString();

        System.out.println("Your UUID is: " + uuidAsString);
        String newMsgReference = "Test";
        String newMsReference = RandomString.make(32);     
        System.out.println(newMsReference);
    
            String input = "jkjkgjgk@#$12334";
            System.out.println(input.replaceAll("[\\w]", ""));
     //       input = input.rep
            
        }
    
    }
    
    
    
    
