package Testing;

import java.io.File;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.w3c.dom.Element;

public class ReadXML {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		  String xmlcon
		  ="<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\">\r\n"
		  + "   <soapenv:Body>\r\n" +
		  "      <cus:EarlySettlementMngRs xmlns:cus=\"http://www.alrajhiwebservices.com/AlrajhiEFinance\" xmlns:alr=\"http://www.alrajhiwebservices.com/\">\r\n"
		  + "         <Hdr>\r\n" + "            <alr:Status>\r\n" +
		  "               <alr:StatusCd>E086012</alr:StatusCd>\r\n" +
		  "               <alr:StatusDesc>Version field validation error</alr:StatusDesc>\r\n"
		  + "            </alr:Status>\r\n" +
		  "            <alr:RqID>d004dab5-f1bd-4289-adb5-6a7800f9aeaf</alr:RqID>\r\n" +
		  "         </Hdr>\r\n" + "      </cus:EarlySettlementMngRs>\r\n" +
		  "   </soapenv:Body>\r\n" + "</soapenv:Envelope>\r\n" + "";
		  
		 		
		try {
			
            File inputFile = new File("INT154.xml");
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.parse(inputFile);
            doc.getDocumentElement().normalize();

            // Specify the tag you want to fetch
            String tagName = "<alr:StatusDesc>";

            NodeList nodeList = doc.getElementsByTagName(tagName);

            for (int temp = 0; temp < nodeList.getLength(); temp++) {
                Node node = nodeList.item(temp);
                if (node.getNodeType() == Node.ELEMENT_NODE) {
                    Element element = (Element) node;
                    // Fetch the value of the tag
                    String tagValue = element.getNodeValue(); 
                    System.out.println(tagValue);
                }
            }
            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}