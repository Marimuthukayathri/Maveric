package Testing;

import org.json.JSONException;
import org.json.JSONObject;

public class UpdateJSON {
    public static void main(String[] args) throws Throwable {
        // Sample JSON string
        String jsonString = "{\r\n"
        		+ "    \"balanceEnquiryHeader\": {\r\n"
        		+ "        \"SenderID\": \"ALFARIS\",\r\n"
        		+ "        \"Receiver\": \"ARB\",\r\n"
        		+ "        \"ServiceType\": \"VABALINQ\",\r\n"
        		+ "        \"SenderTimeStamp\": \"2023-12-19T14:36:35\",\r\n"
        		+ "        \"MsgRetryNo\": \"0\",\r\n"
        		+ "        \"MsgDateTime\": \"2023-10-15T15:12:35\",\r\n"
        		+ "        \"MsgType\": \"Single\",\r\n"
        		+ "        \"MsgReference\": \"Test0000000000043\",\r\n"
        		+ "        \"schemeId\": \"L3TEST05\"\r\n"
        		+ "    },\r\n"
        		+ "    \"balanceEnquiryBody\": {\r\n"
        		+ "        \"clientId\": \"ALFARIS\",\r\n"
        		+ "        \"schemeId\": \"L3TEST05\",\r\n"
        		+ "        \"accountId\": \"SA6680900345678992020377\"\r\n"
        		+ "    },\r\n"
        		+ "    \"SignatureValue\": {\r\n"
        		+ "        \"Signature\": \"\"\r\n"
        		+ "    }\r\n"
        		+ "}";

        // Parse the JSON string into a JSONObject
        JSONObject jsonObject = new JSONObject(jsonString);
        
//        JSONObject jsonObject = new JSONObject(jsonString);

        // Print JSON object
        System.out.println(jsonObject.toString());

        // Update the value associated with the key "age"
        jsonObject.remove("MsgReference");
        System.out.println(jsonObject.getNames(jsonObject));
        
        jsonObject.put("MsgReference", "Test01123343");

        // Convert the updated JSONObject back to a JSON string
        String updatedJsonString = jsonObject.toString();

        // Print the updated JSON string
        System.out.println(updatedJsonString);
    }
}
