package Testing;

import org.json.JSONException;
import org.json.JSONObject;

public class Test {

    public static void main(String[] args) throws Throwable {
        String jsonArray = "{\n" +
                "   \"result\":{\n" +
                "      \"issue_date\":\"20-02-2011\",\n" +
                "      \"father/husband\":\"Chopra\",\n" +
                "      \"name\":\"Variyar\",\n" +
                "      \n" +
                " \"img\":\"/9j/4AAQSkZJRgABAQAABAAD/2wBDAAYEBQYFBAYGBQYHBwYIChAKCgkJChQODwwQFxQYGBcUFhYaHSUfGhsjHBYWICwgIyYnKSopGR8tMC0oMCUoKS\",\n" +
                "      \"blood_group\":\"\",\n" +
                "      \"dob\":\"11-03-1981\",\n" +
                "      \"validity\":{\n" +
                "         \"non-transport\":\"24-03-2010 to 23-02-2030\",\n" +
                "         \"transport\":\"\"\n" +
                "      },\n" +
                "      \"cov_details\":[\n" +
                "         {\n" +
                "            \"issue_date\":\"UNIT OFFICE,TRICHY\",\n" +
                "            \"cov\":\"NCWG\"\n" +
                "         }\n" +
                "      ],\n" +
                "      \"dl_number\":\"TN0290000784\",\n" +
                "      \"address\":\"PERIYA COLONY  KO PAVAZHANGUDI  VIRUDHACHALAM TK\"\n" +
                "   },\n" +
                "   \"request_id\":\"a2642ae9-2f10-4e9a-9f7e-c3ee1a9a2dbe\",\n" +
                "   \"status-code\":\"101\"\n" +
                "}";
        JSONObject jObject = new JSONObject(jsonArray);
        jObject.getJSONObject("result").put("img", "N/A");
        System.out.println(jObject);
    }

}