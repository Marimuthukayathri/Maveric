package Testing;

import java.io.*;
import javax.json.*;


public class UpdateExistingJsonTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		      String jsonString = "{\"id\":\"115\", \"name\":\"Raja\", \"address\":[{\"area\":\"Madhapur\", \"city\":\"Hyderabad\"}]}";
		      StringReader reader = new StringReader(jsonString);
		      JsonReader jsonReader = Json.createReader(reader);
		      System.out.println("Existing JSON: \n" + jsonString);
		      StringWriter writer = new StringWriter();
		      JsonWriter jsonWriter = Json.createWriter(writer);
		      JsonObject jsonObject = jsonReader.readObject();
		      JsonBuilderFactory jsonBuilderFactory = Json.createBuilderFactory(null);
		      JsonObjectBuilder jsonObjectBuilder = jsonBuilderFactory.createObjectBuilder();
		      for(String key : jsonObject.keySet()) {
		         jsonObjectBuilder.add(key, jsonObject.get(key));
		      }
		      jsonObjectBuilder.add("Contact Number", "9959984000");
		      jsonObjectBuilder.add("Country", "India");
		      jsonObject = jsonObjectBuilder.build();
		      jsonWriter.writeObject(jsonObject);
		      System.out.println("new JSON: \n" + jsonObject);
		   

	

}

}