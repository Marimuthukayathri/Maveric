package Exam;

import java.util.*;
import java.util.List;

public class Test1 {

	public static void main(String[] args) {
		
		
		String at = "abcda";
		
		HashMap <Character, Integer> map1 = new HashMap <Character, Integer>();
		
		char [] carray = at.toCharArray();
		
		for (char c: carray) {
			
			if (map1.containsKey(c)) {
				
				map1.put(c, map1.get(c)+1);
			} else  {
				map1.put(c, 1);
			}
		}
		
		
		for (HashMap.Entry <Character, Integer> ent: map1.entrySet()) {
			
			System.out.println("Character : "+ent.getKey()+"   Count :"+ent.getValue());
		}
		
		
		}
		
		
	}


