package test02;

public class dowhilee {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		
			    do{  
			        System.out.println("infinitive do while loop");  
			    }while(false);  
		
	}

}
