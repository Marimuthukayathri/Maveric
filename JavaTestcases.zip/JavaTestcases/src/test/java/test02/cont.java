package test02;

public class cont {

	public static void main(String[] args) {
		
		for (int j=0; j<=6; j++)
		{
	           if (j==4)
	           {
		      continue;
		   }

	           System.out.print(j+ " ");
		}

	}

}
