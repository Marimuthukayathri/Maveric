package test02;

public class usermethod {

	
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	int res;
	res =  square(4);
	System.out.println(res); 
		
		
	}

	public static int square(int i) {
		return i*i;
		// TODO Auto-generated method stub
		 
	}

}
