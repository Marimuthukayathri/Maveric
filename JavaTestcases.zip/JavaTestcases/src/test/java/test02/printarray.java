package test02;

import java.util.Arrays;

public class printarray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		 int[][] array = {{1, 2}, {3, 4}, {5, 6, 7}};

	        System.out.println(Arrays.deepToString(array));

	}

}
