package test02;

import java.io.*;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class WriteExcelSheet {

	public static void main(String[] args) throws Throwable {
		// TODO Auto-generated method stub

		 String filePath = "C:\\Users\\marimuthuc\\Documents\\API\\SOAP API Automation\\TestData\\SOAPAPIDATA.xlsx"; 

		     File file = new File(filePath); 
		     FileInputStream fis = new FileInputStream(file); 
		     XSSFWorkbook wb = new XSSFWorkbook(fis); 
		     XSSFSheet sheet=wb.getSheet("Sheet2"); 
		// Call getRow() method to read row by row number. 
		     XSSFRow row = sheet.getRow(0); // Return type of getRow method is a XSSFRow. 
		     XSSFCell cell = row.createCell(3); 
		     XSSFCell cell1 = row.createCell(2); 
		     cell.setCellValue("Pass"); // This method returns nothing. 
		     cell1.setCellValue("Pass"); // This method returns nothing. 

				
				/*
				 * sheet.getRow(2).createCell(2).setCellValue("Pass");
				 * sheet.getRow(3).createCell(2).setCellValue("Pass");
				 * sheet.getRow(4).createCell(2).setCellValue("Pass");
				 */	 		 
		     FileOutputStream fos = new FileOutputStream(filePath); 
		      wb.write(fos); 
		      fos.close(); 
		      System.out.println("Result Written Successfully"); 
		   } 
		}