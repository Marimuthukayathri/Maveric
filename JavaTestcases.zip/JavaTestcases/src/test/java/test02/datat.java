package test02;

public class datat {

	public static void main(String[] args) {
		
		String s = "Amigo" + " is the best";
		System.out.println(s);  
	
	}

}
