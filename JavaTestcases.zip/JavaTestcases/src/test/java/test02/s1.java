package test02;


public class s1 {

//private static String name = "mari";   
	
		public String setName (String name) {  
		return name;  
		}  
		
	//getter method for name  
	public static void main (String[] args){  
		
	@SuppressWarnings("unused")
	String name;  
	s1 s = new s1();
	
	System.out.println("name is " +(s.setName("mari"))); 
	 
	}
	 
	}  
	//setter method for name  
	