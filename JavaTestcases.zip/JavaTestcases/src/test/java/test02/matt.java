package test02;


import java.text.DecimalFormat;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class matt {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String columnvalue = "1";
		
		String s1 = "1 ";
		//String s1 = "1";
		   
		columnvalue =s1.concat(columnvalue);
		  System.out.println(columnvalue);   
	}

}
