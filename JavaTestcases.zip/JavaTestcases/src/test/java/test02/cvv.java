package test02;

public class cvv {
	
	
	public void cv1() {
		
		String cv[] = {"1", "2", "3", "4", "5", "6", "7", "8", "9"};
		
		
		String columnvalue;
		
	}}
	/*	switch() {
		
		
		case "1": 
			
			if(columnvalue=="1")
			{
				columnvalue = "0001 1";
				return;
			}
            System.out.println("one"); 
            break;
            
        case "2": 
            
        	if(columnvalue=="2")
			{
				columnvalue = "0002 2";
				return;
			}
            System.out.println("twoe"); 
            break;
            
            
        case "3": 
        	if(columnvalue=="3")
			{
				columnvalue = "0003 3";
				return;
			}
            System.out.println("three"); 
            break;
        
        case "4": 
        	if(columnvalue=="4")
			{
				columnvalue = "0004 4";
				return;
			}
            System.out.println("four"); 
            break;
            	
		
        case "5": 
        	if(columnvalue=="5")
			{
				columnvalue = "0005 5";
				return;
			}
            System.out.println("five"); 
            break;
            	
        case "6": 
        	if(columnvalue=="6")
			{
				columnvalue = "0006 6";
				return;
			}
            System.out.println("six"); 
            break;
            	
        case "7": 
        	if(columnvalue=="7")
			{
				columnvalue = "0007 7";
				return;
			}
            System.out.println("seven"); 
            break;
            	
        case "8": 
        	if(columnvalue=="8")
			{
				columnvalue = "0008 8";
				return;
			}
            System.out.println("eight"); 
            break;
            	
        case "9": 
        	if(columnvalue=="9")
			{
				columnvalue = "0009 9";
				return;
			}
            System.out.println("nine"); 
            break;
            
            
            
			}
		
	}

}
*/