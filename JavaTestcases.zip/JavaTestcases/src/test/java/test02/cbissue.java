package test02;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class cbissue {
	
public static WebDriver dr;
	
	
	By email = By.name("username");
	By pwd = By.name("password");
	By Logon = By.xpath("/html/body/div/div[1]/div/div[2]/div/form/div[3]/div[2]/button");
	By path = By.xpath("//div[contains(@id,'tree-root')]/ol/li/div/div[3]/label");
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub (driver.findElement((By.xpath("//div[contains(@class,'circle-checkbox col-md-3 col-sm-3')]"))).getAttribute("class")=='tgl tgl-light ng-untouched ng-valid ng-dirty ng-valid-parse ng-not-empty') {
		
		
		

	}

}
