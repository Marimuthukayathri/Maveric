package test02;

public class switchdd {

	public static void main(String[] args) {
			
			int item = 10;
			
			String product;
			
			switch (item) {
			
			 
			
			case 1:  product = "iphone5";
			
			break;
			
			case 2:  product = "iphone6";
			
			break;
			
			case 3:  product = "iphone7";
			
			break;
			
			case 4:  product = "iphone8";
			
			break;
			
			case 5:  product = "samsung7";
			
			break;
			
			case 6:  product = "samsung8";
			
			break;
			
			case 7:  product = "nokia";
			
			break;
			
			case 8:  product = "macbook";
			
			break;
			
			default: product = "motoG";
			
			break;
			
			}
			

			System.out.println("ent your choice");
			
			
			System.out.println(product);
			
	}
}


