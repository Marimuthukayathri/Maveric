package test02;

public class dowhile {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int rowcount=10;;
		int i=5;
		do {
			
			System.out.println("hai");
			i++;
			
		} while(i<rowcount);
		

	}

}
