package test02;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class chhh {
	
	
public void cc(WebDriver dr) throws InterruptedException { 
	
	
dr.findElement(By.xpath("//label[contains(@for,'cb1171')][contains(@class,'tgl-btn pull-left')]")).click();
	

dr.findElement(By.xpath("//label[contains(@for,'cb1137')][contains(@class,'tgl-btn pull-left')]")).click();
	
	
dr.findElement(By.xpath("//label[contains(@for,'cb1138')][contains(@class,'tgl-btn pull-left')]")).click();
	
	
dr.findElement(By.xpath("//label[contains(@for,'cb13')][contains(@class,'tgl-btn pull-left')]")).click();
	
	
dr.findElement(By.xpath("//label[contains(@for,'cb1139')][contains(@class,'tgl-btn pull-left')]")).click();
	
	
dr.findElement(By.xpath("//label[contains(@for,'cb1140')][contains(@class,'tgl-btn pull-left')]")).click();
	
	
dr.findElement(By.xpath("//label[contains(@for,'cb1141')][contains(@class,'tgl-btn pull-left')]")).click();
	
	
dr.findElement(By.xpath("//label[contains(@for,'cb134')][contains(@class,'tgl-btn pull-left')]")).click();
	
	
dr.findElement(By.xpath("//label[contains(@for,'cb140')][contains(@class,'tgl-btn pull-left')]")).click();
	
	
dr.findElement(By.xpath("//label[contains(@for,'cb1129')][contains(@class,'tgl-btn pull-left')]")).click();
	
	
dr.findElement(By.xpath("//label[contains(@for,'cb1164')][contains(@class,'tgl-btn pull-left')]")).click();
	
	
dr.findElement(By.xpath("//label[contains(@for,'cb1147')][contains(@class,'tgl-btn pull-left')]")).click();


dr.findElement(By.xpath("//label[contains(@for,'cb1155')][contains(@class,'tgl-btn pull-left')]")).click();
	
	
	/*
	
	dr.findElement(By.xpath("//span[contains(.,'Update And Close')]")).click();
	
	Thread.sleep(4000); 
	
	dr.findElement(By.xpath("//a[contains(@class,'ng-binding ng-isolate-scope')]")).click();
	
	Thread.sleep(4000); 
	
	*/

}
}