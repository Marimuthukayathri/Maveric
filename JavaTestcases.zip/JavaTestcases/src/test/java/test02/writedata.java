package test02;

import java.io.FileOutputStream;
import java.io.IOException;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Cell;


public class writedata {

	public static void main(String[] args) throws IOException, Exception  {
	    XSSFWorkbook wb=new XSSFWorkbook();
	    XSSFSheet spreadsheet=wb.createSheet();
	    FileOutputStream fos=null;
	    for(int i=0; i<10; i++) {
	        Row row=spreadsheet.createRow(i);
	    }
	    for(int j=0; j<4; j++) {
	         for(int i=0; i<10;i++){
	           Row row = spreadsheet.getRow(i);
	            Cell value=row.createCell(j);
	            value.setCellValue(i+" Test");
	            }
	        }
	   fos=new FileOutputStream("Testexcel.xlsx");
	   wb.write(fos);

	    wb.close();
	    fos.close();
	 }
	}