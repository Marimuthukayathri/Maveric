package Testcases1;

public class Last3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String t1 = "uhuihhioh87Test";
		
		t1 = t1.substring(11);
		System.out.println(t1);
	}

}
