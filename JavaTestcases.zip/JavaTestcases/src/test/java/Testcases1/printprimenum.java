package Testcases1;

public class printprimenum {

	public static void main(String[] args) {
		
 
		for (int i=1; i<=10; i++) {
			boolean flag = true;
			for (int j=2; j<=i/2; j++) {
				if(i%j==0) {
				flag = false;  
				 System.out.println(i+" is not prime");
				break; 
				}
			}
			if (flag) {
				 System.out.println(i+" is prime");
			}
		}

	}
}
