package Testcases1;

public class chkprimenum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		int n = 15;
		boolean flag = true;
		for (int i=2; i<=n/2; i++) {
			if(n%i==0) {
				flag = false;			}
		}
			
		if(flag) {
		System.out.println(n+" is prime");}
		else {	System.out.println(n+" is not prime");
		}
	}

}
