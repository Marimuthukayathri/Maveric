package Testcases1;

import java.util.Collections;

public class looping {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String input = "coronovo";
		char [] carr = input.toCharArray();
		char ch = '*'; 
		int count =0;
		int xpos =0;
			for(int i=0; i<carr.length; i++) {
			for (int j=i+1; j<carr.length; j++) {
				int ypos=j;
				if(carr[i]==carr[j]) {
				//	carr[i] = '*';   
					System.out.println("\nY pos is "+ypos); 
					count++;
					System.out.println("Count is "+count); 	
//					  String string= input;
					 StringBuilder string = new StringBuilder(input);
					  string.setCharAt(xpos, ch);
	//				 input = string;
					  string.setCharAt(ypos, ch);
					  input =string.toString();
					 for (int v=0;v<count; v++) {
							string = string.insert(ypos, ch);
				        }
					System.out.print(string);
					input =string.toString();
		//			ypos++;
					carr[i] = '0';

				}
			}   
			xpos++; 
			}

	}
}
