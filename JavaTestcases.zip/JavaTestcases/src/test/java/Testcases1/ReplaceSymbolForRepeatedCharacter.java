package Testcases1;

import java.util.HashMap;
import java.util.Map;

public class ReplaceSymbolForRepeatedCharacter {
    
	public static void main(String[] args) {

    	String input = "programming";

        Map<Character, Integer> charCounts = new HashMap<>();
        StringBuilder result = new StringBuilder();

        char symbol = '*';

        for (int i = 0; i < input.length(); i++) {
            char character = input.charAt(i);
            System.out.print(character);
           

            // Update character counts
            if (charCounts.containsKey(character)) {
                charCounts.put(character, charCounts.get(character) + 1);
            } else {
                charCounts.put(character, 1);
            }

            // Replace symbol for repeated characters
            if (charCounts.get(character) > 1) {
                result.append(symbol);
            } else {
                result.append(character);
            }
        }
        System.out.println();

        System.out.println("Original: " + input);
        System.out.println("Modified: " + result.toString());
    }
}
