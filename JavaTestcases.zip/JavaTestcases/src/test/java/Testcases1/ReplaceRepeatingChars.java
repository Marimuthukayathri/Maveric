package Testcases1;

public class ReplaceRepeatingChars {

		    public static void main(String[] args) {

		    	String input = "aaabbbccccddddd";
	//	        String result = replaceRepeatingChars(input);
		    
		    
	//	    public static String replaceRepeatingChars(String input) {
		        StringBuilder output = new StringBuilder();
		        int count = 1;
		        
		        for (int i = 0; i < input.length(); i++) {
		            if (i + 1 < input.length() && input.charAt(i) == input.charAt(i + 1)) {
		                count++;
		            } else {
		                if (count > 1) {
		                    output.append("*").append(count).append(input.charAt(i));
		                } else {
		                    output.append(input.charAt(i));
		                }
		                count = 1;
		            }
		        }
		        
		//        return output.toString();
		        System.out.println(output);
		    	
		    }
		}
	
