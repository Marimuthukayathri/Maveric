package Testcases1;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

//import org.apache.commons.codec.language.bm.Languages;

public class Streamex {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		List<String>languages = new ArrayList <String>();
		languages.add("English");
		languages.add("German");
		languages.add("French");
		languages.add("German");
		languages.add("French");
		languages.add("German");
		languages.add("French");
		
	//	languages.stream().forEach(System.out::println);
	//	languages.stream().sorted().forEach(System.out::println);
		languages.stream().sorted().map(e->e.toUpperCase()).forEach(System.out::println);
		System.out.println();
		Set<String> casell = languages.stream().map(e-> e.toUpperCase()).collect(Collectors.toSet());
		System.out.println(casell);
		
		
		int[] array1 = {21,21,33,43,36,76,88,90,65};
		int max = Arrays.stream(array1).max()	.getAsInt();
		System.out.println("Max "+max);
		int min = Arrays.stream(array1).min().getAsInt();
		System.out.println("Min "+min);
		
		List<Integer> l1 = new ArrayList<Integer>();
		
		for (int i=0; i<array1.length; i++) {
			
			l1.add((array1[i]));
		}
		
		 Optional<Integer> secondLargest = l1.stream()
	                .distinct() // Remove duplicates
	                .sorted(Comparator.reverseOrder()) // Sort the stream in descending order
	                .skip(1) // Skip the largest number
	                .findFirst(); // Find the second largest number

	        // Displaying the second largest number
	        secondLargest.ifPresent(number -> System.out.println("Second Largest Number: " + number));
		
		for (Integer  ee : array1) {
			
			l1.add(ee);
			System.out.print(ee);
		}
		
		System.out.println();
		Collections.sort(l1);
		System.out.println(" Sorted "+l1);
		Collections.reverse(l1);
		System.out.println("Rev "+l1);
		
		Set<Integer> sss = new HashSet<Integer>(l1);
		System.out.println(sss);
		
		
		
		
		

	}

}
