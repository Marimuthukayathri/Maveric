package Tests;

public class InttoArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		int ac = 1000435;
		String and = String.valueOf(ac); 
		
		char[] arr = and.toCharArray();
		
		for (int i=0;i<arr.length; i++) {
			
			System.out.println(arr[i]); 
		}
		
		
		int num1 = 1;
	    int num2 = 13;

	    // convert int to char
	    // for value between 0-9
	    char a = Character.forDigit(num1, 10);

	    // for value between 0-9
	    char b = Character.forDigit(num2, 16);

	    // print value
	    System.out.println(a);    // 1
	    System.out.println(b);   
		
		
		
		

	}

}
