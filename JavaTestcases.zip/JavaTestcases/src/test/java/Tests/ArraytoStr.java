package Tests;

import java.util.Arrays;
import java.util.List;

public class ArraytoStr {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String[] data = {"Turn","Array", "Into", "String","In", "Java", "Example"};
        String joinedstr = String.join(" ", data);
        System.out.println(joinedstr);
        String s = Arrays.toString(data);
        System.out.println(s);
        
        CharSequence[] vowels  = {"a", "e", "i", "o", "u"};
        String joinedvowels = String.join("", vowels);
        System.out.println(joinedvowels);
        List<String> strList = Arrays.asList("dev", "with", "us", "blog");
        String joinedString = String.join(", ", strList);
        System.out.println(joinedString);
        
        
        
        String[] stringArray = {"Apple" , "banana" ,"grape"};
        
        System.out.println(stringArray.length);
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < stringArray.length; i++) {
            sb.append(stringArray[i]);
            if (i < stringArray.length - 1) {
                sb.append(", ");
            }
        }
        
        String result = sb.toString();
        
        System.out.println(result); 
        
        
        

	}

}
