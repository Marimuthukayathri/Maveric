package Tests;

import java.util.*;

public class Remduparray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

			
		int arr[] = {1, 2, 2, 3, 4, 5, 5, 5};
	    System.out.print("Original Array: ");
	    int length = arr.length;
	    for (int i=0; i<length; i++)
	    System.out.print(arr[i]+" ");
		
	    int[] temp = new int[length-1];
	    int j = 0;
	    for (int i=0; i<length-1; i++){
	      if (arr[i] != arr[i+1]){
	        temp[j++] = arr[i];
//	        System.out.println(temp[j]);  
	      }
	    }
	    temp[j++] = arr[length-1];
	    // copying the temp array to the original array
	    for (int i=0; i<j; i++){
	      arr[i] = temp[i];
	    }
		
	    System.out.print("Array after removing duplicate elements: ");
	    for (int i=0; i<j; i++)
	      System.out.print(arr[i]+" ");
		
	    
		/*
		 * int [] array = {1,4,3,2,4,5,1};
		 * 
		 * int[] temp = new int[array.length]; int j=0; for (int i=0; i<array.length-1;
		 * i++) { if(array[i]!=array[i+1]) { temp[j++]= array[i]; //
		 * System.out.println(temp[i++]); }
		 * 
		 * } temp[j++] = array[array.length-1];
		 * 
		 * for (int i=0; i<j; i++) {
		 * 
		 * array[i]= temp[i]; System.out.println(array[i]); }
		 */	
		
		
		
		/*
		 * Set<Integer> setOfInteger = new HashSet<>( Arrays.asList(1,2,3,4,2,1,3)); //
		 * Print the set of Integer System.out.println("Set of Integer: " +
		 * setOfInteger);
		 * 
		 * List <Integer> ArrayL = new ArrayList<Integer>
		 * (Arrays.asList(1,2,3,4,2,1,3)); System.out.println("Array of Integer: " +
		 * ArrayL);
		 * 
		 * List<Integer> al = new ArrayList<>();
		 * 
		 * for (Integer a: ArrayL) { if(!al.contains(a)) al.add(a); }
		 * System.out.println("Duplicates removed Array of Integer: " + al);
		 */		
		
	}

}
