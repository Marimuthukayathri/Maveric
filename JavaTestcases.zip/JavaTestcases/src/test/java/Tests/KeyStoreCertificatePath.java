package Tests;

public class KeyStoreCertificatePath {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String keystorePath = System.getProperty("javax.net.ssl.keyStore");
		System.out.println("Keystore Path: " + keystorePath);

		String truststorePath = System.getProperty("javax.net.ssl.trustStore");
		System.out.println("Truststore Path: " + truststorePath);
	}

}
