package Tests;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class RemdupAL {

	public static void main(String[] args) {
	    List<Object> numbers = new ArrayList<Object>(Arrays.asList(1, 2, 3, 4, 1, 3));
	    System.out.println("ArrayList with duplicate elements: " + numbers);

	    Stream<Object> stream = numbers.stream();  
	    stream = stream.distinct();
	    numbers = stream.collect(Collectors.toList());
	    System.out.println("ArrayList without duplicate elements: " + numbers);
	    
	    
	    
	    
	    
	    
	    

	 
	    
	    
	    
	    
	    
		
	}

}
