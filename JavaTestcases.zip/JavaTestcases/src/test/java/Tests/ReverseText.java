package Tests;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ReverseText {

	public static void main(String[] args) {
        String text = "Hello, World!";
        String reversedText = reverseUsingCollections(text);
        System.out.println("Original Text: " + text);
        System.out.println("Reversed Text: " + reversedText);
    }

    public static String reverseUsingCollections(String input) {
        // Step 1: Convert the string to a list of characters
        List<Character> charList = new ArrayList<>();
        for (char c : input.toCharArray()) {
            charList.add(c);
        }

        // Step 2: Reverse the list using Collections.reverse
        Collections.reverse(charList);

        // Step 3: Convert the reversed list back to a string
        StringBuilder reversedString = new StringBuilder(charList.size());
        for (char c : charList) {
            reversedString.append(c);
        }

        return reversedString.toString();
    }
}
