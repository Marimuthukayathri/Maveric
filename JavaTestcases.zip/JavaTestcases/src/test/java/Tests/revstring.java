package Tests;

import java.util.*;

public class revstring {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String str = "TestTestTesting";  
		String rev = "";
		for (int i=str.length()-1; i>=0;i--) {
			rev += str.charAt(i);
		}
		System.out.println(rev); 
		
		
		
		List <String> arrayl = new ArrayList<>();

		arrayl.add("Test1");
		arrayl.add("Test2");
		arrayl.add("Test3");
		arrayl.add("Test2");
		arrayl.add("Test3");

		HashSet<String> set = new HashSet<>(arrayl);
		
		
		System.out.println(set);
		
	}

}
