package Tests;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class ReverseWords {
    public static void main(String[] args) {
        String text = "Hello, World! This is a test.";
        String reversedWords = reverseWordsUsingCollections(text);
        System.out.println("Original Text: " + text);
        System.out.println("Reversed Words: " + reversedWords);
    }

    public static String reverseWordsUsingCollections(String input) {
        // Step 1: Split the string into words
        String[] wordsArray = input.split("\\s+");
        
        // Step 2: Convert the array to a list
        List<String> wordsList = new ArrayList<>(Arrays.asList(wordsArray));
        
        // Step 3: Reverse the list using Collections.reverse
        Collections.reverse(wordsList);
        
        // Step 4: Join the reversed list back into a string
        StringBuilder reversedString = new StringBuilder();
        for (int i = 0; i < wordsList.size(); i++) {
            reversedString.append(wordsList.get(i));
            if (i < wordsList.size() - 1) {
                reversedString.append(" ");
            }
        }
        
        return reversedString.toString();
    }
}
