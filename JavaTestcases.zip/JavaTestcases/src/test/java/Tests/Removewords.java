package Tests;

import java.util.*;

public class Removewords {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		String s1= "apple banana apple orange banana grape";
		
		String [] splitword = s1.split("\\ ");
		for (String s: splitword) {
			System.out.print(" "+s);
		}
		
		System.out.println();
		
		List <String> list = new ArrayList<>();
		list = Arrays.asList(splitword);
		/*
		 * for (int i=0;i<list.size(); i++) { System.out.println(" "+list.get(i)); }
		 */		
		System.out.println();
		
		Collections.reverse(list);
		System.out.println(list);
		
		System.out.println();
		
		Set <String> setvl = new HashSet<>(list);
		
		for (String ss: setvl) {
		System.out.print("SET   "+ss);} 
		
		System.out.println();
		
		String [] uniq =  setvl.toArray(new String[0]); 
		
		System.out.println(Arrays.toString(uniq)); 
		

		LinkedHashSet <Character> lh = new LinkedHashSet<> ();
		
		for (int i=0;i<s1.length();i++) {
			lh.add(s1.charAt(i));
		}
		
		for (Character c : lh) {
			
			System.out.print(c);
		}
		
		
		List<Integer> list1 = new ArrayList<>();
        list1.add(1);
        list1.add(2);
        list1.add(3);
        list1.add(4);
        list1.add(5);

        List<Integer> list2 = new ArrayList<>();
        list2.add(3);
        list2.add(4);
        list2.add(5);
        list2.add(6);
        list2.add(7);

        // Create a third ArrayList to store the common elements
        List<Integer> commonElements = new ArrayList<>();

        // Find common elements
        for (Integer element : list1) {
            if (list2.contains(element)) {
                commonElements.add(element);
            }
        }
        
        for (int i=0; i<list1.size(); i++) {
        	
        	if (list2.contains(list1)) {
                commonElements.get(i);
            }
        	
        }

        // Print the common elements
        System.out.println("Common elements: " + commonElements);
  
               String input = "HelloWorld123";

                // StringBuilder objects to store capital and small characters
                StringBuilder capitals = new StringBuilder();
                StringBuilder smalls = new StringBuilder();

                // Iterate through each character of the input string
                for (char ch : input.toCharArray()) {
                    // Check if the character is a capital letter
                    if (Character.isUpperCase(ch)) {
                        capitals.append(ch);
                    }
                    // Check if the character is a small letter
                    else if (Character.isLowerCase(ch)) {
                        smalls.append(ch);
                    }
                }

                // Convert StringBuilder to String and print the results
                System.out.println("Capital characters: " + capitals.toString());
                System.out.println("Small characters: " + smalls.toString());
            }
        }

		
	