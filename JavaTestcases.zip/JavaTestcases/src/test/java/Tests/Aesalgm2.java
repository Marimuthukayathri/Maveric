package Tests;

import java.util.Arrays;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;
import javax.xml.bind.DatatypeConverter;

public class Aesalgm2 {

	public static void main(String[] args) {
		
	try {
        final String message = "Testing Message";  
        final String password = "Testing@12345";

        // Here the magic numbers
        final int pswdIterations = 65;
        final int keySize = 128;

        final byte[] saltBytes = {0};

        SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1");
        PBEKeySpec spec = new PBEKeySpec(password.toCharArray(), saltBytes,12, keySize);
        SecretKey secretKey = factory.generateSecret(spec);
        SecretKeySpec secret = new SecretKeySpec(secretKey.getEncoded(), "AES");

        // Instantiate the cipher
        Cipher cipher = Cipher.getInstance("AES");

        // Encrypt
        cipher.init(Cipher.ENCRYPT_MODE, secret);
        byte[] encrypted = cipher.doFinal(message.getBytes());
        System.out.println("Original string: " + message);
        System.out.println("Encrypted string: " + Arrays.toString(encrypted));

        // Decrypt
        cipher.init(Cipher.DECRYPT_MODE, secret);
        byte[] decrypt_original = cipher.doFinal(encrypted);
        String decrypt_originalString = new String(decrypt_original);
        System.out.println("Decrypt string: " + decrypt_originalString);
    } catch (Exception ex) {
    	ex.printStackTrace();
    }
   
}
}