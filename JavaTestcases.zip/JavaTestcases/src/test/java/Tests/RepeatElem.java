package Tests;

public class RepeatElem {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		String str = "corconac";
		String x=null; int i,j = 0; char temp = 0;
		char[] arr = str.toCharArray();
		for ( i=0; i<str.length(); i++) {
			int count =1;
			for (j=i+1; j<str.length(); j++) {
			if(str.charAt(i)==str.charAt(j)) {
			count++;	
			temp=str.charAt(i);
			char temp1=str.charAt(j);
		//	str.replace( temp , '*'); 
		
			}
		} 	System.out.println(str.replace( str.charAt(i) , '*'));   
			break;

		}
		
		
	}

}
