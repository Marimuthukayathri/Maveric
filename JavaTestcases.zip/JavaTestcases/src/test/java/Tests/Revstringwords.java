package Tests;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class Revstringwords {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String s1= "apple banana apple orange banana grape";
		
		String[] wordsArray = s1.split("\\ ");
		
		 List<String> wordsList = new ArrayList<>(Arrays.asList(wordsArray));
	        
	        Collections.reverse(wordsList);

		System.out.println(wordsList);
	}

}
