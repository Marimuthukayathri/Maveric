package Tests;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class RemoveDuplicates {
    public static void main(String[] args) {
        // Example array with duplicate strings
        String[] stringArray = {"apple", "banana", "apple", "orange", "banana", "grape"};

        // Convert array to list
        List<String> stringList = Arrays.asList(stringArray);

        // Create a Set from the List to remove duplicates
        Set<String> stringSet = new HashSet<>(stringList);

        // Convert the Set back to an array
        String[] uniqueArray = stringSet.toArray(new String[0]);

        // Print the array without duplicates
        System.out.println("Array without duplicates: " + Arrays.toString(uniqueArray));
    }
}