package Mavtest;

public class stringmeth {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String name = "Test";
		String nam = new String ("Test");
		System.out.println(nam);
		System.identityHashCode(nam);
		System.out.println(name.hashCode()); // 2301506
	    System.out.println(nam.hashCode()); // 1377009627
	    
	    String str1 = new String("xyz");
	    String str2 = new String("xyz");


	    System.out.println(str1 == str2); // false
//	    System.out.println(name = nam); // false
	    System.out.println(name == nam); // false
	    
		
		
	}

}
