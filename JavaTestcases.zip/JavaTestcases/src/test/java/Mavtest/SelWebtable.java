package Mavtest;


	import org.openqa.selenium.By;
	import org.openqa.selenium.WebDriver;
	import org.openqa.selenium.WebElement;
	import org.openqa.selenium.chrome.ChromeDriver;
	import java.util.List;

	public class SelWebtable {

		public static void main(String[] args) {

			System.setProperty("webdriver.chrome.driver", "path/to/chromedriver");

	        // Initialize WebDriver
	        WebDriver driver = new ChromeDriver();

	        try {
	            // Open the desired webpage
	            driver.get("http://example.com/webtable");

	            // Locate the table by its ID or any other attribute
	            WebElement table = driver.findElement(By.id("tableID"));

	            // Locate rows of the table
	            List<WebElement> rows = table.findElements(By.tagName("tr"));

	            // Iterate over each row to get cells
	            for (WebElement row : rows) {
	                // Locate columns/cells in the current row
	                List<WebElement> cells = row.findElements(By.tagName("td"));

	                // Print cell values
	                for (WebElement cell : cells) {
	                    System.out.print(cell.getText() + "\t");
	                }
	                System.out.println();
	            }
	        } finally {
	            // Close the browser
	            driver.quit();
	        }
	    }
	}
