package Mavtest;

public class prime100 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int lim = 100;
//		System.out.println(Math.sqrt(lim));
		
		int count =0;
		for (int num=2; num<=lim;num++) {
			boolean isprime = true;
			
			for (int i =2;i<=num/2;i++) {
			if (num%i==0) {
				isprime = false;
				break;
			}
		}
	
			if(isprime) {
				count++;
				System.out.print(num+" ");
				System.out.println(count);
			}
	}
			

	
	}

	}


