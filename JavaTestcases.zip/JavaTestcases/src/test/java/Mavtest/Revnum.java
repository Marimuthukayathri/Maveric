package Mavtest;

public class Revnum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int num =125489;
		int rev =0;
		
		
		  while(num!=0) {
			  int dig = num%10; 
			  rev = rev*10+dig; 
			  num = num/10; 
			  }
		 		
			/*
			 * for(;num != 0; num /=10) { int digit = num % 10; rev = rev * 10 + digit; }
			 */
		System.out.println(rev);
		
	}

}
